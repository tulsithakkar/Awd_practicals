// Develop HTTP server to display user details with /userData request. (Consider the data in JSON format)

const http = require("http");
const userData = {
  name: "Dhaval Chhayla",
  age: 22,
  email: "23mca022@charusat.edu.in",
  profession: "DevOps Engineer",
};

const server = http.createServer((req, res) => {
  if (req.url === "/userData") {
    res.end(JSON.stringify(userData));
  } else {
    res.end("Welcome!");
  }
});

server.listen(3000, () => {
  console.log("Server running at http://localhost:3000/");
});
