// Write a Node.js program that outputs "Hello, Node.js!" to the console.

console.log("Hello, Node.js!");