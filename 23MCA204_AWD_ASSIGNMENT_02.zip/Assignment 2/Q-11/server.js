// Create Application to redirect requests to a different URL. -> Using req.redirect()

const express = require("express");
const app = express();
app.use(express.json());

// Route to Main Page
app.get("/", (req, res) => {
  res.send("Main Page");
});

// Route to redirect to an external URL
app.get("/github", (req, res) => {
  res.redirect("https://github.com/DhavalChhaylaOfficial");
});

// Route to redirect to another internal route
app.get("/old-route", (req, res) => {
  res.redirect("/new-route"); // Redirects to '/new-route'
});

// New internal route as a target for the redirect
app.get("/new-route", (req, res) => {
  res.send("You have been redirected to the new route!");
});

app.listen(2011, () => {
  console.log(`Server is running on http://localhost:2011/`);
});
