/* Create Restful APIs in expressJS to display the data of task (taskID, taskName, status – started / completed/ /in progress). 
Allow user to update the status in the order (1. Started 2. In Progress 3. Completed). 
Create APIs – Read and update the data. */

const express = require("express");
const app = express();
app.use(express.json());
let tasks = [
  { taskID: 1, taskName: "Task 1", status: "Started" },
  { taskID: 2, taskName: "Task 2", status: "In Progress" },
  { taskID: 3, taskName: "Task 3", status: "Completed" },
];

app.get("/tasks", (req, res) => {
  res.json(tasks);
});

app.put("/tasks/:taskID/status", (req, res) => {
  const taskID = parseInt(req.params.taskID);
  const task = tasks.find((t) => t.taskID === taskID);

  if (!task) {
    return res.status(404).json({ message: "Task not found" });
  }
  if (task.status === "Started") {
    task.status = "In Progress";
  } else if (task.status === "In Progress") {
    task.status = "Completed";
  } else {
    return res.status(400).json({ message: "Task is already completed" });
  }

  res.json(task);
});
app.listen(2013, () => {
  console.log(`Server is running on http://localhost:2013/`);
});
