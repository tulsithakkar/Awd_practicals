console.log('Controller.js loaded');

const ctrl = angular.module("DemoApp", []);
ctrl.controller("DemoCtrl", function ($scope, $http) {
    $scope.msg = "Controller.js loaded";
})