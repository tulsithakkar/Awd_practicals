/* Serve static files like HTML, JS, and images using ExpressJS. 
-> Use Express’s built-in express.static() middleware to serve files from a public folder. 
-> Place a sample index.html, angular.js, controller.js and an image file in the public folder. 
=> Access the static files from a browser. */

const express = require("express");
const path = require("path");

const app = express();
app.use(express.static(path.join(__dirname, "public")));

app.listen(2012, () => {
  console.log(`Server is running on http://localhost:2012/`);
});
