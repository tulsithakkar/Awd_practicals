/* Develop basic HTTP server to perform Math Operation (+,-,*,/) according to request send in the URL (/Add,/Sub,/Mul,/Div). 
Also display the result with Number1, Number2, Result, Greater Number, Smaller Number) */

//To test: http://localhost:3000/Add?num1=5&num2=3
const http = require("http");
const url = require("url");

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const queryObject = parsedUrl.query;
  const pathname = parsedUrl.pathname;

  const num1 = parseFloat(queryObject.num1);
  const num2 = parseFloat(queryObject.num2);

  let result;
  let operation;
  let greater, smaller;

  if (num1 > num2) {
    greater = num1;
    smaller = num2;
  } else if (num1 < num2) {
    greater = num2;
    smaller = num1;
  } else {
    greater = smaller = num1;
  }

  if (pathname === "/Add") {
    result = num1 + num2;
    operation = "Addition";
  } else if (pathname === "/Sub") {
    result = num1 - num2;
    operation = "Subtraction";
  } else if (pathname === "/Mul") {
    result = num1 * num2;
    operation = "Multiplication";
  } else if (pathname === "/Div") {
    if (num2 === 0) {
      res.end("Cannot divide by zero");
      return;
    }
    result = num1 / num2;
    operation = "Division";
  } else {
    res.end(
      "/Add For Addition, /Sub for Substraction, /Mul Multiplication, /Div Division"
    );
    return;
  }
  res.end(
    `Operation: ${operation}\nNumber1: ${num1}\nNumber2: ${num2}\nResult: ${result}\nGreater Number: ${greater}\nSmaller Number: ${smaller}`
  );
});

server.listen(3000, () => {
  console.log("Server running at http://localhost:3000/");
});
