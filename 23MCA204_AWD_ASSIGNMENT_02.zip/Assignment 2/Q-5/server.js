// Develop basic http server to take the number1, number2 and operator from the url with querystring and display the result.

//to Test: http://localhost:3000/?number1=10&number2=5&operator=add

const http = require("http");
const url = require("url");

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const queryObject = parsedUrl.query;

  const num1 = parseFloat(queryObject.number1);
  const num2 = parseFloat(queryObject.number2);
  const operator = queryObject.operator;

  let result;
  switch (operator) {
    case "add":
      result = num1 + num2;
      break;
    case "sub":
      result = num1 - num2;
      break;
    case "mul":
      result = num1 * num2;
      break;
    case "div":
      if (num2 === 0) {
        res.end("Cannot divide by zero");
        return;
      }
      result = num1 / num2;
      break;
    default:
      res.end("Invalid operator. Use add, sub, mul, or div.");
      return;
  }
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end(`Result is ${result}`);
});

server.listen(3000, () => {
  console.log("Server running at http://localhost:3000/");
});
