// Create different routes for different HTTP methods. (GET,POST,PUT,DELETE)

const express = require("express");
const app = express();
app.use(express.json());

let items = [
  { itemID: "Item1", itemName: "Pani-Puri" },
  { itemID: "Item2", itemName: "Burgir" },
  { itemID: "Item3", itemName: "Pizza" },
  { itemID: "Item4", itemName: "Pasta" },
];

app.get("/items", (req, res) => {
  res.json(items);
});

app.post("/items", (req, res) => {
  items.push(req.body);
  res.status(201).json(req.body);
});

app.put("/items/:index", (req, res) => {
  const index = req.params.index;
  if (items[index]) {
    items[index] = req.body;
    res.json(items[index]);
  } else {
    res.status(404).send("Item not found");
  }
});

app.delete("/items/:index", (req, res) => {
  const index = req.params.index;
  if (items[index]) {
    const deletedItem = items.splice(index, 1);
    res.json(deletedItem);
  } else {
    res.status(404).send("Item not found");
  }
});

app.listen(2010, () => {
  console.log(`Server is running on http://localhost:2010/`);
});
