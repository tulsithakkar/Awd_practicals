/* Develop a basic HTTP server that responds with “Welcome to Home/Student/Faculty” 
according to request sent in the URL with different route - /home, /student, /faculty. */

const http = require("http");
const server = http.createServer((req, res) => {
  if (req.url === "/home") {
    res.end("Welcome to Home");
  } else if (req.url === "/student") {
    res.end("Welcome to Student");
  } else if (req.url === "/faculty") {
    res.end("Welcome to Faculty");
  } else {
    res.end("Welcome to Our App!");
  }
});
server.listen(3000, () => {
  console.log("Server running at http://localhost:3000/");
});
