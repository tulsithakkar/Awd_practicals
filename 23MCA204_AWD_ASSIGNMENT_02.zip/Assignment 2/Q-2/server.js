// Develop a basic HTTP server that responds with "Welcome to the NodeJS App” to any request.

const http = require("http");
const server = http.createServer((req, res) => {
  res.end("Welcome to the NodeJS App");
});
server.listen(3000, () => {
  console.log(`Server running at http://localhost:3000/`);
});
