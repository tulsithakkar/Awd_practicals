const app = angular.module('productApp', []);
app.controller('ProductController', function($scope, $http) {
    $http.get('http://localhost:3000/api/products')
        .then(function(response) {
            $scope.products = response.data;
        })
        .catch(function(error) {
            console.error('Error fetching products:', error);
        });
});