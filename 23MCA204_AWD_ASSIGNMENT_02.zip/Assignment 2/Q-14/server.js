/* Develop MEAN Stack application to display product data. 
-> Product (id, name, category, price, image) 
-> Create APIs to access product details. 
-> Display the product details in proper format. 
 */

const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname)));

const products = [
    { id: 1, name: "Laptop", category: "Category 1", price: 100, image: "laptop.png" },
    { id: 2, name: "Mobile", category: "Category 2", price: 200, image: "mobile.png" },
    { id: 3, name: "Headphone", category: "Category 3", price: 300, image: "image.png" }
];

app.get('/api/products', (req, res) => {
    res.json(products);
});

app.listen(3000, () => {
    console.log(`Server is running on http://localhost:3000/`);
});
